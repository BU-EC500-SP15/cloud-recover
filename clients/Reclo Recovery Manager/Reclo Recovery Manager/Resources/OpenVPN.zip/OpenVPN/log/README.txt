This directory will contain the log files for OpenVPN
sessions which are being run as a service.
